package com.csch.yizhi.flutter_yizhi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
